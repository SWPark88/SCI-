package kr.co.siren24.auth.authorizationserver.oauth;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Data
@Table(name = "TB_OAUTH_CREDENTIALS")
public class OauthCredentialsDTO {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "USER_ID")
	private String userId;
	@Column(name = "SERVICE_ID")
	private String serviceId;
	@Column(name = "CLIENT_ID")
	private String clientId;
	@Column(name = "CLIENT_SECRET")
    private String clientSecret;
}