package kr.co.siren24.auth.authorizationserver.common.util;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

public class HttpServletRequestUtil {
	public static String fetchClientIpAddr(HttpServletRequest request) {
	    String ip = Optional.ofNullable(request.getHeader("X-FORWARDED-FOR")).orElse(request.getRemoteAddr());
	    if ("0:0:0:0:0:0:0:1".equals(ip)) ip = "127.0.0.1";
	    return ip;
	}
}