package kr.co.siren24.auth.authorizationserver.common.dto;

import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

import kr.co.siren24.auth.authorizationserver.common.constant.LangCode;
import kr.co.siren24.auth.authorizationserver.common.constant.ResponseMsg;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DataHeader {
	@Pattern(regexp = "(kr)|(en)", message = "0001")
	@JsonProperty(value = "lang_code")
	private String langCode;
	@JsonProperty(value = "result_code")
	private String resultCode;
	@JsonProperty(value = "result_msg")
	private String resultMsg;
	public DataHeader() {
		this.langCode = LangCode.kr;
		this.resultCode = ResponseMsg.E1400.getCode();
		this.resultMsg = ResponseMsg.E1400.getMsgKr();
	}
}