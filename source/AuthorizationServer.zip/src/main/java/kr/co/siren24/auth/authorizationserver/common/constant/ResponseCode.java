package kr.co.siren24.auth.authorizationserver.common.constant;

import org.springframework.util.StringUtils;

import lombok.Getter;

public class ResponseCode {
	public final static String S1200 = "S1200";
	public final static String E1300 = "E1300";
	public final static String E1400 = "E1400";
}