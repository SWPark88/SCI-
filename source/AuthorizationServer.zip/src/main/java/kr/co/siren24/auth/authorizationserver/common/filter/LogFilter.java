package kr.co.siren24.auth.authorizationserver.common.filter;

import java.io.IOException;
import java.util.UUID;

import lombok.extern.slf4j.Slf4j;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.MDC;
import org.springframework.core.annotation.Order;
import org.springframework.web.filter.OncePerRequestFilter;

import kr.co.siren24.auth.authorizationserver.common.util.HttpServletRequestUtil;

@Slf4j
public class LogFilter extends OncePerRequestFilter {
	@Override
	public void doFilterInternal(HttpServletRequest httpRequest, HttpServletResponse httpResponse, FilterChain filterChain) throws IOException, ServletException {
	    String uuid = UUID.randomUUID().toString();
	    MDC.put("traceId", uuid);
	    String requestURI = httpRequest.getRequestURI();
	    String remoteAddr = HttpServletRequestUtil.fetchClientIpAddr(httpRequest);

	    try {
	        log.info("REQUEST  [{}][{}]", requestURI, remoteAddr);
	        filterChain.doFilter(httpRequest, httpResponse);
	    } catch (Exception e) {
	    	log.error("[{}][{}]", requestURI, remoteAddr);
	        throw e;
	    } finally {
	        log.info("RESPONSE [{}][{}]", requestURI, remoteAddr);
	        MDC.clear();
	    }
	}
}