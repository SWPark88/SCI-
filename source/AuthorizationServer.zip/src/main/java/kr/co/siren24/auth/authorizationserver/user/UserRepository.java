package kr.co.siren24.auth.authorizationserver.user;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import lombok.Getter;
import lombok.Setter;

@Repository
public interface UserRepository extends JpaRepository<UserVo, Long> {
	List<UserVo> findByUsername(String username);
}
