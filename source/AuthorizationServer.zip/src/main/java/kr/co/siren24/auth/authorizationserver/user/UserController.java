package kr.co.siren24.auth.authorizationserver.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/user")
    public List<UserVo> listUser() {
        return userService.findAll();
    }
    
    @PostMapping("/getuser")
    public UserVo getUser(@RequestBody UserVo user) {
        return userService.get(user);
    }

    @PostMapping("/user")
    public UserVo create(@RequestBody UserVo user) {
        return userService.save(user);
    }

}