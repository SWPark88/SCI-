package kr.co.siren24.auth.authorizationserver.common.constant;

public class LangCode {
	public final static String kr = "kr";
	public final static String en = "en";
}
