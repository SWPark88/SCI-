package kr.co.siren24.auth.authorizationserver.common.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;

import kr.co.siren24.auth.authorizationserver.common.util.HttpServletRequestUtil;

public class BaseController {
	@Autowired 
	private HttpServletRequest httpRequest;
	
	protected String fetchClientIpAddr() {
		return HttpServletRequestUtil.fetchClientIpAddr(httpRequest);
	}
}