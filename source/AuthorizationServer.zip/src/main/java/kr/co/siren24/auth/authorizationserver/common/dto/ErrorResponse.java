package kr.co.siren24.auth.authorizationserver.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ErrorResponse extends BaseResponse {
	private Object dataBody;
}
