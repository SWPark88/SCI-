package kr.co.siren24.auth.authorizationserver.oauth;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

import kr.co.siren24.auth.authorizationserver.common.constant.ResponseCode;
import kr.co.siren24.auth.authorizationserver.common.constant.ResponseMsg;
import kr.co.siren24.auth.authorizationserver.common.dto.BaseRequest;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OauthAccessTokenRequest extends BaseRequest {
	@Valid
	private DataBody dataBody;
}

@Getter
@Setter
class DataBody {
    @Pattern(regexp = "(default)", message = ResponseCode.E1400)
    @JsonProperty(value = "scope")
    private String scope;
    
    @Pattern(regexp = "(client_credentials)", message = ResponseCode.E1400)
    @JsonProperty(value = "grant_type")
    private String grantType;
}