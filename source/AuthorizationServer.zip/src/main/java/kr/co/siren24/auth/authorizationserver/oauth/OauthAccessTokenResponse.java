package kr.co.siren24.auth.authorizationserver.oauth;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

import kr.co.siren24.auth.authorizationserver.common.constant.ResponseCode;
import kr.co.siren24.auth.authorizationserver.common.dto.BaseResponse;
import kr.co.siren24.auth.authorizationserver.common.dto.DataHeader;

@Getter
public class OauthAccessTokenResponse extends BaseResponse {
	private OauthAccessTokenDataBody dataBody;
    
    public OauthAccessTokenResponse(DataHeader dataHeader) {
    	super.setDataHeader(dataHeader);
    	this.dataBody = new OauthAccessTokenDataBody();
    }

    @Builder
    public OauthAccessTokenResponse(DataHeader dataHeader, OauthAccessTokenDataBody dataBody) {
    	super.setDataHeader(dataHeader);
        this.dataBody = dataBody;
    }
}

@Getter
@Setter
class OauthAccessTokenDataBody {
	@SerializedName(value = "access_token")
	@JsonProperty(value = "access_token")
    private final String accessToken;
	@SerializedName(value = "token_type")
	@JsonProperty(value = "token_type")
    private final String tokenType;
	@SerializedName(value = "expires_in")
	@JsonProperty(value = "expires_in")
    private final long expiresIn;
	@SerializedName(value = "scope")
	@JsonProperty(value = "scope")
    private final String scope;
    
    public OauthAccessTokenDataBody() {
        this.accessToken = "";
        this.tokenType = "";
        this.expiresIn = 0L;
        this.scope = "";
    }
    
    @Builder
    public OauthAccessTokenDataBody(String accessToken, String tokenType, long expiresIn, String scope) {
        this.accessToken = accessToken;
        this.tokenType = tokenType;
        this.expiresIn = expiresIn;
        this.scope = scope;
    }
}