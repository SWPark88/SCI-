package kr.co.siren24.auth.authorizationserver.common.dto;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.google.gson.annotations.SerializedName;

import kr.co.siren24.auth.authorizationserver.oauth.OauthAccessTokenRequest;

@Getter
@Setter
public class BaseRequest {
	private DataHeader dataHeader = new DataHeader();
}