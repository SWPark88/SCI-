package kr.co.siren24.auth.authorizationserver.oauth;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

import javax.validation.Valid;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.google.gson.annotations.JsonAdapter;

import kr.co.siren24.auth.authorizationserver.common.constant.ResponseMsg;
import kr.co.siren24.auth.authorizationserver.common.controller.BaseController;
import kr.co.siren24.auth.authorizationserver.common.dto.DataHeader;
import kr.co.siren24.auth.authorizationserver.common.filter.LogFilter;
import kr.co.siren24.auth.authorizationserver.common.util.HttpServletResponseUtil;
import kr.co.siren24.auth.authorizationserver.user.UserRepository;
import kr.co.siren24.auth.authorizationserver.user.UserService;
import kr.co.siren24.auth.authorizationserver.user.UserVo;

@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/oauth/oauth")
public class OauthController extends BaseController{
	private final Gson gson;
	private final RestTemplate restTemplate;
	private final OauthCredentialsRepository oauthCredentialsRepository;
	private final OauthAccessPermitRepository oauthAccessPermitRepository;
	
    @PostMapping(value = "/token")
    public OauthAccessTokenResponse oauthCreateAccessToken(@RequestHeader HttpHeaders httpHeaders, @RequestBody @Valid OauthAccessTokenRequest oauthAccessTokenRequest) {
    	// 해더 정보에서 basic 인증 정보 획득
    	// Authorization
    	// = Basic cm9vdDEwbTpyb290
    	// = "Basic " + Base64Encoding(client_id:client_secret)
    	String authorization = httpHeaders.getFirst("Authorization");
    	if (!StringUtils.hasText(authorization)) {
    		HttpServletResponseUtil.fetchDataHeader(oauthAccessTokenRequest.getDataHeader(), ResponseMsg.E1400);
    		return new OauthAccessTokenResponse(oauthAccessTokenRequest.getDataHeader());
		}
    	
    	// 불필요 문자열 제거
		String encodedCredentials = StringUtils.delete(authorization, "Basic ");
		if (!StringUtils.hasText(encodedCredentials)) {
			return null;
		}
		
		// 디코딩
		String decodedCredentials = new String(Base64.decodeBase64(encodedCredentials));
		
		// 디코딩 된 인증정보에서 client_id, client_secret 분리
		String[] credentialsArray = StringUtils.split(decodedCredentials, ":");
		if (ObjectUtils.isEmpty(credentialsArray) || credentialsArray.length != 2) {
			return null;
		}
		
		String clientId = credentialsArray[0];
		String clientSecret = credentialsArray[1];
		// 클라이언트 IP 획득
		String clientIpAddr = fetchClientIpAddr();
		
		// 인증 정보 검증
		List<OauthCredentialsDTO> credentialsDTOs = oauthCredentialsRepository.findByClientIdAndClientSecret(clientId, clientSecret);
		if (ObjectUtils.isEmpty(credentialsDTOs)) {
			return null;
		}
		
		// 접근 허용 검증
		List<OauthAccessPermitDTO> accessPermitDTOs = oauthAccessPermitRepository.findByClientIdAndClientAccessIp(clientId, clientIpAddr);
		if (ObjectUtils.isEmpty(accessPermitDTOs)) {
			return null;
		}
		
		// Oauth2 서버에서 token을 호출하여 access_token 획득
		return OauthAccessTokenResponse.builder()
				.dataHeader(oauthAccessTokenRequest.getDataHeader())
				.dataBody(getToken(authorization))
				.build();
    }
    
    /**
     * Oauth2 서버에서 token을 호출하여 access_token 획득
     * @param authorization
     * @return access_token
     */
    private OauthAccessTokenDataBody getToken(String authorization) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.add("Authorization", authorization);

        // 인증 서버로부터 Access Token 을 발급 받기 위해 필요한 파라미터 생성
        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("grant_type", "client_credentials"); // 권한 코드 승인 방식을 사용
        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(params, headers);

        // Oauth2 서버 통신
        // Access Token 발급 요청
        ResponseEntity<String> response = restTemplate.postForEntity("http://localhost:8080/oauth/token", request, String.class);

        if (response.getStatusCode() == HttpStatus.OK) {
            return gson.fromJson(response.getBody(), OauthAccessTokenDataBody.class);
        }
        return null;
    }
    
    @PostMapping(value = "/revoke")
    public OauthAccessTokenResponse oauthRevokeAccessToken(@RequestHeader HttpHeaders httpHeaders, @RequestBody @Valid OauthAccessTokenRequest oauthAccessTokenRequest) {
    	// 해더 정보에서 basic 인증 정보 획득
    	// Authorization
    	// = Basic 
    	// = "Basic " + Base64Encoding(client_id:current_timestamp:client_secret)
    	String authorization = httpHeaders.getFirst("Authorization");
    	if (!StringUtils.hasText(authorization)) {
    		HttpServletResponseUtil.fetchDataHeader(oauthAccessTokenRequest.getDataHeader(), ResponseMsg.E1400);
    		return new OauthAccessTokenResponse(oauthAccessTokenRequest.getDataHeader());
		}
    	
    	// 불필요 문자열 제거
		String encodedCredentials = StringUtils.delete(authorization, "Basic ");
		if (!StringUtils.hasText(encodedCredentials)) {
			return null;
		}
		
		// 디코딩
		String decodedCredentials = new String(Base64.decodeBase64(encodedCredentials));
		
		// 디코딩 된 인증정보에서 client_id, current_timestamp, client_secret 분리
		String[] credentialsArray = StringUtils.split(decodedCredentials, ":");
		if (ObjectUtils.isEmpty(credentialsArray) || credentialsArray.length != 2) {
			return null;
		}
		
		String clientId = credentialsArray[0];
		String clientSecret = credentialsArray[1];
		// 클라이언트 IP 획득
		String clientIpAddr = fetchClientIpAddr();
		
		// 인증 정보 검증
		List<OauthCredentialsDTO> credentialsDTOs = oauthCredentialsRepository.findByClientIdAndClientSecret(clientId, clientSecret);
		if (ObjectUtils.isEmpty(credentialsDTOs)) {
			return null;
		}
		
		// 접근 허용 검증
		List<OauthAccessPermitDTO> accessPermitDTOs = oauthAccessPermitRepository.findByClientIdAndClientAccessIp(clientId, clientIpAddr);
		if (ObjectUtils.isEmpty(accessPermitDTOs)) {
			return null;
		}
		
		// Oauth2 서버에서 token을 호출하여 access_token 획득
		return OauthAccessTokenResponse.builder()
				.dataHeader(oauthAccessTokenRequest.getDataHeader())
				.dataBody(getToken(authorization))
				.build();
    }
}