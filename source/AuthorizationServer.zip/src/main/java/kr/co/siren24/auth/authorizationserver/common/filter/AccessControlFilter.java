package kr.co.siren24.auth.authorizationserver.common.filter;

import java.io.IOException;
import java.time.Duration;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import lombok.extern.slf4j.Slf4j;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.web.filter.GenericFilterBean;
import org.springframework.web.filter.OncePerRequestFilter;

import io.github.bucket4j.Bandwidth;
import io.github.bucket4j.Bucket;
import io.github.bucket4j.Refill;
import kr.co.siren24.auth.authorizationserver.common.util.HttpServletRequestUtil;

@Slf4j
public class AccessControlFilter extends OncePerRequestFilter {
	int capacity = 10;
    int refillTokens = 10;
    Duration refillDuration = Duration.ofMinutes(1);

    private static final Map<String, Bucket> CACHE = new ConcurrentHashMap<>();

    private Bucket createNewBucket() {
        Refill refill = Refill.intervally(refillTokens, refillDuration);
        Bandwidth limit = Bandwidth.classic(capacity, refill);
        return Bucket.builder().addLimit(limit).build();
    }

    @Override
    public void doFilterInternal(HttpServletRequest httpRequest, HttpServletResponse httpResponse, FilterChain filterChain) throws IOException, ServletException {
    	String requestURI = httpRequest.getRequestURI();
	    String remoteAddr = HttpServletRequestUtil.fetchClientIpAddr(httpRequest);
        Bucket bucket = CACHE.computeIfAbsent(remoteAddr, k -> createNewBucket());

        // tryConsume returns false immediately if no tokens available with the bucket
        if (bucket.tryConsume(1)) {
            // the limit is not exceeded
        	log.info("ALLOW ACCESS [{}][{}]", requestURI, remoteAddr);
            filterChain.doFilter(httpRequest, httpResponse);
        } else {
            // limit is exceeded
        	log.info("DENY ACCESS  [{}][{}]", requestURI, remoteAddr);
            httpResponse.setContentType("text/plain");
            httpResponse.setStatus(HttpStatus.TOO_MANY_REQUESTS.value());
            httpResponse.getWriter().append("{\"message\":\"요청이 너무 많습니다. 1분후 다시 시도해주세요.\"}");
        }

    }
}