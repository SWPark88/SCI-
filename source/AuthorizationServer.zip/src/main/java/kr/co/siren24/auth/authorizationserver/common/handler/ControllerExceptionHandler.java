package kr.co.siren24.auth.authorizationserver.common.handler;

import java.lang.reflect.Type;
import java.util.List;

import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;

import kr.co.siren24.auth.authorizationserver.common.constant.ResponseCode;
import kr.co.siren24.auth.authorizationserver.common.constant.ResponseMsg;
import kr.co.siren24.auth.authorizationserver.common.dto.BaseRequest;
import kr.co.siren24.auth.authorizationserver.common.dto.BaseResponse;
import kr.co.siren24.auth.authorizationserver.common.dto.DataHeader;
import kr.co.siren24.auth.authorizationserver.common.dto.ErrorResponse;
import kr.co.siren24.auth.authorizationserver.oauth.OauthAccessPermitRepository;
import kr.co.siren24.auth.authorizationserver.oauth.OauthAccessTokenRequest;
import kr.co.siren24.auth.authorizationserver.oauth.OauthCredentialsRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestControllerAdvice
@Slf4j
public class ControllerExceptionHandler {

	@ExceptionHandler(BindException.class)
	public Object bindExceptionHandler(BindException e) {
		return fetchErrorResponse(e.getBindingResult());
	}
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Object validExceptionHandler(MethodArgumentNotValidException e) {
		return fetchErrorResponse(e.getBindingResult());
	}
	
	private Object fetchErrorResponse(BindingResult bindingResult) {
		List<ObjectError> erros = bindingResult.getAllErrors();
		String code = erros.get(0).getDefaultMessage();
		ResponseMsg responseMsg = ResponseMsg.valueOf(code);
		
		Object obj = bindingResult.getTarget();
		String langCode = ((BaseRequest)obj).getDataHeader().getLangCode();
		((BaseRequest)obj).getDataHeader().setResultCode(responseMsg.getCode());
		((BaseRequest)obj).getDataHeader().setResultMsg(responseMsg.getMsgByLang(langCode));
		
		return obj;
	}
	
	@ExceptionHandler(Exception.class)
	public String custom(Exception e) {
//		BindingResult bindingResult = e.getBindingResult();
//		Object obj = bindingResult.getTarget();
//		((BaseRequestDTO)obj).getDataHeader().setResultCode("0001");
//		((BaseRequestDTO)obj).getDataHeader().setResultMsg("error");
//		List<ObjectError> erros = bindingResult.getAllErrors();
//		
//		String message = erros.get(0).getDefaultMessage();
//cause	MethodArgumentNotValidException  (id=159)	

		return "";
	}

}
