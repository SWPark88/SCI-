package kr.co.siren24.auth.authorizationserver.user;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Data
@Table(name = "user_vo")
public class UserVo {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long uid;

    private String username;

    private String password;


}