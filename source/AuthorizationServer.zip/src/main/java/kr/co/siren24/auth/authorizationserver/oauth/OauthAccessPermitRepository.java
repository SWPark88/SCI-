package kr.co.siren24.auth.authorizationserver.oauth;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import lombok.Getter;
import lombok.Setter;

@Repository
public interface OauthAccessPermitRepository extends JpaRepository<OauthAccessPermitDTO, String> {
	List<OauthAccessPermitDTO> findByClientIdAndClientAccessIp(String clientId, String clientAccessIp);
}
