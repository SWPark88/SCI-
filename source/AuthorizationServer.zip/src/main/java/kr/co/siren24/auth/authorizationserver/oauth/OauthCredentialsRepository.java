package kr.co.siren24.auth.authorizationserver.oauth;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface OauthCredentialsRepository extends JpaRepository<OauthCredentialsDTO, String>, QueryByExampleExecutor<OauthCredentialsDTO> {
	List<OauthCredentialsDTO> findByClientIdAndClientSecret(String clientId, String clientSecret);
}