package kr.co.siren24.auth.authorizationserver.common.util;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import kr.co.siren24.auth.authorizationserver.common.constant.ResponseMsg;
import kr.co.siren24.auth.authorizationserver.common.dto.DataHeader;

public class HttpServletResponseUtil {
	public static void fetchDataHeader(DataHeader dataHeader, ResponseMsg responseMsg) {
		dataHeader.setResultCode(responseMsg.getCode());
		dataHeader.setResultMsg(responseMsg.getMsgByLang(dataHeader.getLangCode()));
	}
}