package kr.co.siren24.auth.authorizationserver.common.constant;

import org.springframework.util.StringUtils;

import lombok.Getter;

@Getter
public enum ResponseMsg {
	S1200(ResponseCode.S1200, "오류 없음 (정상)", "No Error"),
	E1300(ResponseCode.E1300, "request body가 비었습니다.", "Request Body is Null"),
	E1400(ResponseCode.E1400, "잘못된 요청", "bad Request"),
	
	;
	
	private final String code;
	private final String msgKr;
	private final String msgEn;
	
	private ResponseMsg(String code, String msgKr, String msgEn) {
		this.code = code;
		this.msgKr = msgKr;
		this.msgEn = msgEn;
	}
	
	public String getMsgByLang(String lang) {
		return StringUtils.hasText(lang) && LangCode.kr.equals(lang) ? msgKr : msgEn;
	}
}
