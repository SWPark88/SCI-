package kr.co.siren24.auth.authorizationserver;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthorizationServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
